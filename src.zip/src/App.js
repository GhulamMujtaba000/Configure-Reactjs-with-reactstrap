import logo from './logo.svg';
import { Navbar, NavbarBrand } from 'reactstrap';
import './App.css';

function App() {
  return (
    <div className="App">
      <div className="container">
          {/* <h1>Old Sukkur vs New Sukkur Match on 6th/oct/2021 </h1>
          <h2>Venu Numaish Ground Old Sukkur</h2>

          <div className ="text-primary">  
            <h2>Old Sukkur Batting Order</h2> 
          </div>
              <div className="text-danger">
                <h2>Bobi    1st  Batsman</h2>
                <h2>moeed   2nd  Batsman</h2>
                <h2>Asad    3rd  Batsman</h2>
                <h2>Jibran  4th  Allrounder</h2>
              </div>
                <div className="text-success">
                  <h2>M.Ali   5th  Batsman Captain & Wicket keeper</h2>
                  <h2>Qazim   6th  Batsman</h2>
                  <h2>Azhar   7th  Allrounder</h2>
                </div>
                  <div className="text-warning">
                    <h2>Zubair  8th  Allrounder</h2>
                    <h2>Imam-bux 9th Bowlwer</h2>
                    <h2>Zaheer  10th Bowler </h2>
                    <h2>Rahib   11th Bowler</h2>
                  </div> */}
                  <Navbar dar color="primary">
                    <NavbarBrand href="/">My first Reactstrap navbar</NavbarBrand>
                  </Navbar>
      </div>

    </div>
  );
}

export default App;
